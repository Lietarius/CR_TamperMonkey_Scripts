// ==UserScript==
// @name         Кнопки для ЛК ФНС
// @version      0
// @author       Шадрин Сергей
// @match        https://lkul.nalog.ru/kkt/
// @match        https://lkul.nalog.ru/kkt/index
// @match        https://lkul.nalog.ru/kkt/index/index
// @grant        none
// @updateURL https://mcmagjp.github.io/CR_TamperMonkey_Scripts/Buttons_LK_FNS.js
// @downloadURL https://mcmagjp.github.io/CR_TamperMonkey_Scripts/Buttons_LK_FNS.js
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
})();