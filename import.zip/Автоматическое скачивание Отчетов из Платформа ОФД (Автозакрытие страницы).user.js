// ==UserScript==
// @name         Автоматическое скачивание Отчетов из Платформа ОФД (Автозакрытие страницы)
// @version      0
// @author       Шадрин Сергей
// @match        https://lk.platformaofd.ru/web/noauth/cheque/*
// @grant        window.close
// @updateURL https://mcmagjp.github.io/CR_TamperMonkey_Scripts/Reports_from_PlatformaOFD_AutoClose.js
// @downloadURL https://mcmagjp.github.io/CR_TamperMonkey_Scripts/Reports_from_PlatformaOFD_AutoClose.js
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
})();