// ==UserScript==
// @name         Автоматическое скачивание Отчетов из OFD.RU
// @version      0
// @author       Шадрин Сергей
// @match        https://lk.ofd.ru/*
// @grant        none
// @updateURL https://mcmagjp.github.io/CR_TamperMonkey_Scripts/Reports_from_OFDRU.js
// @downloadURL https://mcmagjp.github.io/CR_TamperMonkey_Scripts/Reports_from_OFDRU.js
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
})();