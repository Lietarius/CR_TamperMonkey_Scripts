// ==UserScript==
// @name         Автоматическое скачивание Отчетов из Такскома
// @version      0
// @author       Шадрин Сергей
// @match        https://lk-ofd.taxcom.ru/
// @match        https://lk-ofd.taxcom.ru/%23
// @grant        none
// @updateURL https://mcmagjp.github.io/CR_TamperMonkey_Scripts/Reports_from_Taxcom.js
// @downloadURL https://mcmagjp.github.io/CR_TamperMonkey_Scripts/Reports_from_Taxcom.js
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
})();