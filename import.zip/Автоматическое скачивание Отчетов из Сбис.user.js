// ==UserScript==
// @name         Автоматическое скачивание Отчетов из Сбис
// @version      0
// @author       Шадрин Сергей
// @match        https://online.sbis.ru/
// @grant        none
// @updateURL https://mcmagjp.github.io/CR_TamperMonkey_Scripts/Reports_from_Sbis.js
// @downloadURL https://mcmagjp.github.io/CR_TamperMonkey_Scripts/Reports_from_Sbis.js
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
})();