// ==UserScript==
// @name         Автоматическое скачивание Отчетов из Платформа ОФД
// @version      0
// @author       Шадрин Сергей
// @match        https://lk.platformaofd.ru/web/noauth/cheque/*
// @grant        none
// @updateURL https://mcmagjp.github.io/CR_TamperMonkey_Scripts/Reports_from_PlatformaOFD.js
// @downloadURL https://mcmagjp.github.io/CR_TamperMonkey_Scripts/Reports_from_PlatformaOFD.js
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
})();